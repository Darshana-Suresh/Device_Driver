#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <linux/input.h>
#include <unistd.h>

#define MOUSEFILE "/dev/mbdriver"
//
int main()
{

	//brightness vars
	
	FILE *fp;
  	int currentBrightness = 0;
  	const char *kFileName ="/sys/class/backlight/intel_backlight/brightness";
  	
  	//get current brightness

  	
  	//mouse vars
    int fd;
    struct input_event ie;
    unsigned char *ptr = (unsigned char*)&ie;
    unsigned char button,bLeft,bMiddle,bRight;
    char x,y;
    
                                                              
    if((fd = open(MOUSEFILE, O_RDONLY | O_NONBLOCK )) == -1){
    
        printf("Error in opening file\n");
        exit(EXIT_FAILURE);
    }
    
    
    printf("Right click to increase brightness\n");
    printf("Left click to decrease brightness\n");
    printf("Middle click to stop\n\n");
    
    while(1)
    {       
        if(read(fd, &ie, sizeof(struct input_event))!=-1)
        {
            
                        
            button=ptr[0];
            
            if(button!=0) {
            
            bLeft = button & 0x1;
            bMiddle = ( button & 0x4 ) > 0;
            bRight = ( button & 0x2 ) > 0;
            printf("Left : %d\n", bLeft);
            printf("Right : %d\n", bRight);
            printf("Middle : %d\n", bMiddle);
            printf("---------\n");
            x=(char) ptr[1];y=(char) ptr[2];
            
            //check for middleButton press
			if(bMiddle == 1){
				break;
			}
            

            //increase brightness
            if (bRight==1){
            
            	//get current brightness
            	fp = fopen(kFileName, "r");
    			fscanf(fp, "%d", &currentBrightness);
    			fclose(fp);	
    			//increase
    			if(currentBrightness >= 700){
                        printf("Max brightness reached\n");
                        bRight = 0;
    			continue;
    			}
    			else{
       				fp = fopen(kFileName, "w");
     				fprintf(fp, "%d\n", currentBrightness+500);
     				fclose(fp);			
    			}
            }
            
            }
            
            //decrease brightness
            if(bLeft == 1){
               
            	//get current brightness
            	fp = fopen(kFileName, "r");
    			fscanf(fp, "%d", &currentBrightness);
    			fclose(fp);	
    			//increase
                        if(currentBrightness <= 46 ){
                        printf("Reached minimum brightness\n");
                        bLeft = 0;
    			continue;
    			}
    			else{  bLeft = 0;
       				fp = fopen(kFileName, "w");
     				fprintf(fp, "%d\n", currentBrightness-50);
     				fclose(fp);			
    			}
                        	
            }
            fflush(stdout);
        }
    }
    
    close(fd);
    fflush(stdout);
return 0;
}
